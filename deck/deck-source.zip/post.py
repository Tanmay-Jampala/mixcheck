"""Post-process raw.pptx -> final deck:
- whole-shape hyperlinks for buttons (names containing 'btn' or 'trig' keep their run link on the shape)
- Morph transition on every slide (fade fallback)
- animations: auto entrances ('auto<ms>-' fade in, 'wipe<ms>-' wipe up) and click triggers
  (trig-d0..3 switch the Mix Dial states d1..d3, trig-qp / trig-qf reveal the quiz answers qp / qf)
"""
import os, re, shutil, subprocess, sys

D = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(D, sys.argv[1] if len(sys.argv) > 1 else "raw.pptx")
out = os.path.join(D, sys.argv[2] if len(sys.argv) > 2 else "MixCheck-Pitch.pptx")
work = os.path.join(D, "px")
shutil.rmtree(work, ignore_errors=True)
subprocess.run(["unzip", "-q", src, "-d", work], check=True)

MORPH = ('<mc:AlternateContent xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006">'
         '<mc:Choice xmlns:p159="http://schemas.microsoft.com/office/powerpoint/2015/09/main" Requires="p159">'
         '<p:transition spd="slow" xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main" p14:dur="900">'
         '<p159:morph option="byObject"/></p:transition></mc:Choice>'
         '<mc:Fallback><p:transition spd="slow"><p:fade/></p:transition></mc:Fallback></mc:AlternateContent>')


class Ids:
    def __init__(self):
        self.n = 2
    def next(self):
        self.n += 1
        return self.n


def effect(ids, spid, kind, delay=0, node="withEffect", grp=0):
    """One animation effect. kind: fade | wipe | appear | hide."""
    cls = "exit" if kind == "hide" else "entr"
    preset = {"fade": 10, "wipe": 22, "appear": 1, "hide": 1}[kind]
    sub = 4 if kind == "wipe" else 0
    vis = "hidden" if kind == "hide" else "visible"
    inner = (f'<p:set><p:cBhvr><p:cTn id="{ids.next()}" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn>'
             f'<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl><p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst>'
             f'</p:cBhvr><p:to><p:strVal val="{vis}"/></p:to></p:set>')
    if kind in ("fade", "wipe"):
        filt = "fade" if kind == "fade" else "wipe(up)"
        dur = 450 if kind == "fade" else 600
        inner += (f'<p:animEffect transition="in" filter="{filt}"><p:cBhvr><p:cTn id="{ids.next()}" dur="{dur}"/>'
                  f'<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl></p:cBhvr></p:animEffect>')
    return (f'<p:par><p:cTn id="{ids.next()}" presetID="{preset}" presetClass="{cls}" presetSubtype="{sub}" fill="hold" '
            f'grpId="{grp}" nodeType="{node}"><p:stCondLst><p:cond delay="{delay}"/></p:stCondLst>'
            f'<p:childTnLst>{inner}</p:childTnLst></p:cTn></p:par>')


def main_seq(ids, effects):
    seq_id = ids.next()
    outer, mid = ids.next(), ids.next()
    return (f'<p:seq concurrent="1" nextAc="seek"><p:cTn id="{seq_id}" dur="indefinite" nodeType="mainSeq"><p:childTnLst>'
            f'<p:par><p:cTn id="{outer}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/>'
            f'<p:cond evt="onBegin" delay="0"><p:tn val="{seq_id}"/></p:cond></p:stCondLst><p:childTnLst>'
            f'<p:par><p:cTn id="{mid}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>'
            + "".join(effects) +
            '</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn>'
            '<p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst>'
            '<p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq>')


def trigger_seq(ids, trig, effects):
    seq_id, a, b = ids.next(), ids.next(), ids.next()
    return (f'<p:seq concurrent="1" nextAc="seek"><p:cTn id="{seq_id}" restart="whenNotActive" fill="hold" '
            f'evtFilter="cancelBubble" nodeType="interactiveSeq"><p:stCondLst><p:cond evt="onClick" delay="0">'
            f'<p:tgtEl><p:spTgt spid="{trig}"/></p:tgtEl></p:cond></p:stCondLst>'
            f'<p:endSync evt="end" delay="0"><p:rtn val="all"/></p:endSync><p:childTnLst>'
            f'<p:par><p:cTn id="{a}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>'
            f'<p:par><p:cTn id="{b}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>'
            + "".join(effects) +
            '</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn>'
            f'<p:nextCondLst><p:cond evt="onClick" delay="0"><p:tgtEl><p:spTgt spid="{trig}"/></p:tgtEl></p:cond></p:nextCondLst></p:seq>')


SP = re.compile(r"<p:sp>.*?</p:sp>", re.S)
sd = os.path.join(work, "ppt", "slides")
summary = []
for f in sorted(os.listdir(sd), key=lambda x: int(re.sub(r"\D", "", x) or 0)):
    if not re.fullmatch(r"slide\d+\.xml", f):
        continue
    p = os.path.join(sd, f)
    x = open(p, encoding="utf-8").read()

    def fix(m):  # move a run hyperlink onto the whole shape for buttons
        s = m.group(0)
        name = re.search(r'<p:cNvPr id="\d+" name="([^"]*)"', s)
        if not name or not re.search(r"btn", name.group(1)):
            return s
        h = re.search(r'<a:hlinkClick (r:id="[^"]*")(?: action="([^"]+)")?', s)
        if not h:
            return s
        attrs = h.group(1) + (f' action="{h.group(2)}"' if h.group(2) else "")
        s = re.sub(r'(<p:cNvPr id="\d+" name="[^"]*"[^>]*?)\s*>\s*</p:cNvPr>', rf"\1><a:hlinkClick {attrs}/></p:cNvPr>", s, count=1)
        s = re.sub(r'(<p:cNvPr id="\d+" name="[^"]*"[^>]*?)\s*/>', rf"\1><a:hlinkClick {attrs}/></p:cNvPr>", s, count=1)
        head, body = s.split("</p:nvSpPr>", 1)
        body = re.sub(r"<a:hlinkClick [^>]*?/>", "", body)
        body = re.sub(r"<a:hlinkClick [^>]*?>.*?</a:hlinkClick>", "", body, flags=re.S)
        return head + "</p:nvSpPr>" + body.replace(' u="sng"', "")

    x = SP.sub(fix, x)
    shapes = {name: int(i) for i, name in re.findall(r'<p:cNvPr id="(\d+)" name="([^"]*)"', x)}
    ids, grp = Ids(), {}

    def g(spid):
        grp[spid] = grp.get(spid, -1) + 1
        return grp[spid]

    seqs = []
    autos = []
    for name, spid in shapes.items():
        m = re.match(r"(auto|wipe)(\d+)-", name)
        if m:
            autos.append((int(m.group(2)), spid, "fade" if m.group(1) == "auto" else "wipe"))
    if autos:
        autos.sort()
        seqs.append(main_seq(ids, [effect(ids, spid, kind, delay=ms, grp=g(spid)) for ms, spid, kind in autos]))
    # Mix Dial triggers
    states = {k: [spid for name, spid in shapes.items() if name.startswith(f"d{k}-")] for k in (1, 2, 3)}
    for k in range(4):
        trig = shapes.get(f"trig-d{k}")
        if trig is None:
            continue
        effs, first = [], True
        for j in (1, 2, 3):
            for spid in states[j]:
                kind = "appear" if j == k else "hide"
                effs.append(effect(ids, spid, kind, node="clickEffect" if first else "withEffect", grp=g(spid)))
                first = False
        seqs.append(trigger_seq(ids, trig, effs))
    # Quiz triggers
    for mine, other in (("qp", "qf"), ("qf", "qp")):
        trig = shapes.get(f"trig-{mine}")
        if trig is None:
            continue
        show = [spid for name, spid in shapes.items() if name.startswith(mine + "-")]
        hide = [spid for name, spid in shapes.items() if name.startswith(other + "-")]
        effs = [effect(ids, s_, "hide", node="clickEffect" if i == 0 else "withEffect", grp=g(s_)) for i, s_ in enumerate(hide)]
        effs += [effect(ids, s_, "fade", node="withEffect" if effs else ("clickEffect" if i == 0 else "withEffect"), grp=g(s_)) for i, s_ in enumerate(show)]
        seqs.append(trigger_seq(ids, trig, effs))

    if "<p:transition" not in x:
        x = x.replace("</p:clrMapOvr>", "</p:clrMapOvr>" + MORPH, 1)
    if seqs:
        timing = ('<p:timing><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst>'
                  + "".join(seqs) + "</p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>")
        x = x.replace("</mc:AlternateContent>", "</mc:AlternateContent>" + timing, 1)
    summary.append(f"{f}: {len(autos)} auto, {len(seqs)} sequences")
    open(p, "w", encoding="utf-8").write(x)

if os.path.exists(out):
    os.remove(out)
subprocess.run(f'cd "{work}" && zip -qXr "{out}" .', shell=True, check=True)
print("\n".join(summary))
print("->", out)
