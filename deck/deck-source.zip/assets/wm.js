const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1800,height:1000}});
await p.goto('file://'+process.cwd()+'/wm.html');await p.waitForTimeout(800);
await (await p.$('#wm')).screenshot({path:'wordmark.png',omitBackground:true});
await (await p.$('#wmw')).screenshot({path:'wordmark_white.png',omitBackground:true});
await b.close();})();
