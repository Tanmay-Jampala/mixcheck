const React=require('react'),RDS=require('react-dom/server'),sharp=require('sharp');
const fa=require('react-icons/fa');
const names=['FaLanguage','FaRobot','FaSearch','FaVial','FaBalanceScale','FaGlobeAsia','FaUserGraduate','FaFlask','FaUsers','FaCode','FaDatabase','FaChartBar','FaGithub','FaPython','FaBolt','FaMicrophone','FaTrophy','FaRocket','FaCheck','FaTimes','FaTag','FaCommentSlash','FaEye','FaLaptopCode','FaExchangeAlt','FaArrowRight','FaShieldAlt','FaServer','FaLayerGroup','FaExternalLinkAlt','FaMousePointer','FaWrench','FaCloud','FaQuestion','FaCheckCircle','FaTimesCircle','FaUserCheck','FaRedo','FaBuilding','FaStar'];
(async()=>{for(const n of names){ for (const [suf,col] of [['w','#FFFFFF'],['i','#1E1A4D'],['a','#E8890C'],['b','#6C5CE7'],['g','#12B886'],['r','#E8456B'],['f','#A9A3CF']]){
 const svg=RDS.renderToStaticMarkup(React.createElement(fa[n],{color:col,size:256}));
 await sharp(Buffer.from(svg)).resize(256,256,{fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).png().toFile(`ic/${n}_${suf}.png`);}}
 console.log('ok')})();
