// MixCheck pitch deck: official AVISHKAR template topics (10 slides), MixCheck website colours,
// interactive widgets (Mix Dial and quiz with click triggers), Morph transitions, live link + QR.
// QA=1 node build.js  -> also writes extra preview slides for each hidden widget state.
const pptxgen = require("pptxgenjs");
const fs = require("fs");
const A = __dirname + "/assets/";
const data = JSON.parse(fs.readFileSync(A + "data.json", "utf8"));
const QA = process.env.QA === "1";
const STATIC = process.env.STATIC === "1";   // no hidden widget states (for the PDF copy)
const URL = "https://mixcheck-elrata.streamlit.app";

const C = {
  ink: "1E1A4D", muted: "5B577E", faint: "8D88B5", card: "FFFFFF", line: "DCD6F7", soft: "F4F1FF",
  brand: "6C5CE7", brandL: "9B8CFF", acc: "FF9F1C", accD: "D97706", pass: "12B886", passL: "2BD9A0",
  fail: "E8456B", failL: "FF5C7A", frame: "7F79B6",
  deep: "0E0B1F", dSurf: "17132E", dSurf2: "211B42", dLine: "2E2759", dText: "F2EFFF", dMuted: "A9A3CF", dFaint: "6F6A99",
  hi: "FF9F1C", bn: "4CC9F0", kn: "E87BA4", ta: "9EE493", or: "FFD166", code: "C9C2FF",
  hiD: "D97706", bnD: "1590B8", knD: "C2477D", taD: "2F9E4F", orD: "B88300",
};
const H = "Lora", B = "Poppins", M = "Consolas";
const W = 13.333;
const N = 10;

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE";
pres.author = "Team El Rata Alada";
pres.title = "MixCheck - AVISHKAR 2026";
pres.theme = { headFontFace: H, bodyFontFace: B };

const ic = (n, c = "w") => A + `ic/${n}_${c}.png`;
let uid = 0;
const nm = (p) => `${p}-${++uid}`;

function T(s, text, o) {
  s.addText(text, Object.assign({ fontFace: B, color: C.ink, fontSize: 13, margin: 0, isTextBox: true, valign: "top" }, o));
}
function card(s, x, y, w, h, o = {}) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x, y, w, h, rectRadius: o.r ?? 0.14,
    fill: { color: o.fill ?? C.card, transparency: o.ft ?? 0 },
    line: o.noLine ? { type: "none" } : { color: o.line ?? C.line, width: o.lw ?? 1 },
    shadow: o.shadow === false ? undefined : { type: "outer", color: o.shColor ?? "6C5CE7", opacity: o.shOp ?? 0.16, blur: 12, offset: 3, angle: 90 },
    objectName: o.name ?? nm("card"),
  });
}
function circle(s, x, y, d, color, o = {}) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color, transparency: o.ft ?? 0 },
    line: o.line ? { color: o.line, width: o.lw ?? 1.5 } : { type: "none" }, objectName: o.name ?? nm("dot") });
}
function badge(s, icon, x, y, d, color, iconColor = "w", name) {
  circle(s, x, y, d, color, { name: name ? name + "-c" : undefined });
  const p = d * 0.26;
  s.addImage({ path: ic(icon, iconColor), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, objectName: name ? name + "-i" : nm("icon") });
}
function pill(s, text, x, y, w, h, o = {}) {
  const runs = [{ text, options: o.link ? { hyperlink: o.link } : {} }];
  s.addText(runs, { x, y, w, h, shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: h / 2,
    fill: { color: o.fill ?? C.card, transparency: o.ft ?? 0 }, line: o.line === null ? { type: "none" } : { color: o.line ?? C.line, width: o.lw ?? 1 },
    fontFace: o.font ?? B, fontSize: o.size ?? 10.5, bold: o.bold ?? true, color: o.color ?? C.ink,
    align: "center", valign: "middle", margin: 0, objectName: o.name ?? nm("pill"), charSpacing: o.cs });
}
const LANG = { en: C.dText, code: C.code, hi: C.hi, bn: C.bn, kn: C.kn, ta: C.ta, or: C.or };
const LANG_LIGHT = { en: C.ink, code: C.brand, hi: C.hiD, bn: C.bnD, kn: C.knD, ta: C.taD, or: C.orD };
function words(tags, size, dark = true) {
  const pal = dark ? LANG : LANG_LIGHT;
  return tags.map(([w, l], i) => ({ text: w + (i < tags.length - 1 ? " " : ""),
    options: { color: pal[l] || pal.en, bold: l !== "en" && l !== "code", fontFace: l === "code" ? M : B, fontSize: l === "code" ? size - 1 : size } }));
}
function codeRuns(lines) {
  const out = [];
  lines.forEach((ln, i) => ln.forEach((r, j) => out.push({ text: r[0], options: Object.assign({ color: r[1] }, r[2] || {}, j === ln.length - 1 && i < lines.length - 1 ? { breakLine: true } : {}) })));
  return out;
}

// ---------- the template frame on every slide ----------
const TOPICS = ["Project Name", "Problem Statement", "Solution", "Tech Stack + Workflow", "Innovation", "Impact",
  "Target Audience / Market", "Revenue Model", "Future Improvements", "Thank You"];
function frame(s, n, o = {}) {
  s.background = { color: "EEEAFB" };
  s.addImage({ path: A + (o.titleBg ? "bg_title.jpg" : "bg.jpg"), x: 0, y: 0, w: W, h: 7.5, objectName: "!!bg" });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.2, y: 0.2, w: 12.93, h: 7.1, rectRadius: 0.2, fill: { type: "none" },
    line: { color: C.frame, width: 2.25 }, objectName: "!!frame" });
  s.addImage({ path: A + "logo_jain.png", x: 0.45, y: 0.36, w: 1.44, h: 0.42, objectName: "!!logo-jain" });
  s.addImage({ path: A + "logo_avi.png", x: (W - 1.73) / 2, y: 0.35, w: 1.73, h: 0.43, objectName: "!!logo-avi" });
  s.addImage({ path: A + "logo_fet.png", x: 11.78, y: 0.3, w: 1.1, h: 0.5, objectName: "!!logo-fet" });
  if (o.title) {
    T(s, o.title, { x: 0.6, y: 0.92, w: W - 1.2, h: 0.62, fontFace: H, fontSize: 30, bold: true, align: "center", valign: "middle", objectName: "!!title" });
    if (o.sub) T(s, o.sub, { x: 1.2, y: 1.52, w: W - 2.4, h: 0.4, fontSize: 13, color: C.brand, align: "center", valign: "middle", objectName: "!!sub" });
  }
  // footer: team, clickable slide dots, live link
  T(s, "MixCheck  ·  Team El Rata Alada", { x: 0.5, y: 6.93, w: 3.4, h: 0.24, fontSize: 9, color: C.faint, objectName: "!!foot-l" });
  const d = 0.24, gap = 0.09, x0 = (W - (N * d + (N - 1) * gap)) / 2;
  for (let i = 1; i <= N; i++) {
    const on = i === n;
    s.addText([{ text: String(i), options: { hyperlink: { slide: i, tooltip: TOPICS[i - 1] } } }], {
      x: x0 + (i - 1) * (d + gap), y: 6.93, w: d, h: d, shape: pres.shapes.OVAL,
      fill: { color: on ? C.brand : C.card, transparency: on ? 0 : 10 }, line: { color: on ? C.brand : C.line, width: 0.75 },
      fontFace: B, fontSize: 7.5, bold: true, color: on ? "FFFFFF" : C.muted, align: "center", valign: "middle", margin: 0,
      objectName: `!!btn-nav-${i}`,
    });
  }
  s.addText([{ text: "● Live: mixcheck-elrata.streamlit.app", options: { hyperlink: { url: URL, tooltip: "Open the live MixCheck dashboard" } } }], {
    x: 9.3, y: 6.9, w: 3.55, h: 0.3, fontFace: B, fontSize: 9, bold: true, color: C.brand, align: "right", valign: "middle", margin: 0, objectName: "!!btn-live" });
}
const notes = (s, t) => s.addNotes(t);

// =====================================================================
// 1. PROJECT NAME
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 1, { titleBg: true });
  pill(s, "AVISHKAR 2026  ·  AI & IoT TRACK", 0.65, 1.25, 3.2, 0.34, { fill: C.acc, line: null, color: "FFFFFF", size: 9.5, cs: 1 });
  s.addImage({ path: A + "wordmark.png", x: 0.5, y: 1.62, w: 6.5, h: 6.5 * 420 / 1447, objectName: "!!wordmark" });
  T(s, [{ text: "Same coding task. Different language.", options: { breakLine: true } }, { text: "Does the AI still get it right?", options: { color: C.brand } }],
    { x: 0.65, y: 3.55, w: 7.0, h: 1.0, fontFace: H, fontSize: 25, bold: true });
  T(s, "A robustness tester for AI coding assistants, using prompts in code-mixed Indian languages.", { x: 0.65, y: 4.65, w: 6.3, h: 0.6, fontSize: 13, color: C.muted });
  pill(s, "</>  Cross-lingual code-switching robustness tester", 0.65, 5.38, 4.35, 0.38, { line: C.brand, color: C.brand, size: 10 });
  pill(s, "Try it live  →", 5.12, 5.38, 1.65, 0.38, { fill: C.brand, line: null, color: "FFFFFF", size: 10, link: { url: URL, tooltip: URL }, name: "btn-try1" });
  T(s, [{ text: "Team El Rata Alada", options: { bold: true } }, { text: "  —  Tanmay, Ritobroto, Aaditya, Aaliya", options: { color: C.muted } }],
    { x: 0.65, y: 6.05, w: 7.2, h: 0.35, fontSize: 13.5 });
  const bubbles = [
    ["HINGLISH", C.hiD, [["yeh", "hi"], ["function", "en"], ["crash", "en"], ["kyu", "hi"], ["ho", "hi"], ["raha", "hi"], ["hai?", "hi"]], 8.45, 1.3],
    ["BENGLISH", C.bnD, [["ei", "bn"], ["list", "en"], ["ta", "bn"], ["sort", "en"], ["kore", "bn"], ["dao", "bn"]], 8.95, 2.33],
    ["KANGLISH", C.knD, [["bari", "kn"], ["code", "en"], ["kodu", "kn"]], 8.3, 3.36],
    ["TANGLISH", C.taD, [["indha", "ta"], ["code-la", "ta"], ["enna", "ta"], ["error?", "en"]], 8.9, 4.39],
    ["ODIA-ENGLISH", C.orD, [["ei", "or"], ["function", "en"], ["ta", "or"], ["fix", "en"], ["karida", "or"]], 8.5, 5.42],
  ];
  bubbles.forEach(([lab, col, tags, x, y], i) => {
    const t0 = 150 + i * 160;
    card(s, x, y, 3.95, 0.86, { line: col, lw: 1.25, r: 0.2, name: `auto${t0}-bub${i}` });
    T(s, lab, { x: x + 0.22, y: y + 0.1, w: 3.4, h: 0.22, fontSize: 8.5, bold: true, color: col, charSpacing: 1.5, objectName: `auto${t0}-bubl${i}` });
    T(s, words(tags, 13.5, false), { x: x + 0.22, y: y + 0.36, w: 3.65, h: 0.4, objectName: `auto${t0}-bubt${i}` });
  });
  notes(s, "AALIYA: Hi, we're El Rata Alada and this is MixCheck. Lots of us ask AI for code the way we talk: half English, half Hindi, Bengali or Kannada. We tested whether the AI still gets it right.");
}

// =====================================================================
// 2. PROBLEM STATEMENT  (+ interactive "spot the failure" quiz)
// =====================================================================
const PAL = [[["def ", C.acc], ["is_palindrome", C.brandL], ["(s: str) -> bool:", C.dText]], [["    return ", C.acc], ["s == s[::-1]", C.dText]]];
function quizReveal(s, correct, prefix) {
  const y = 5.3;
  card(s, 4.95, y, 7.6, 1.25, { fill: correct ? "0F3B33" : "3B1424", line: correct ? C.passL : C.failL, lw: 1.5, shadow: false, name: `${prefix}-bg` });
  s.addImage({ path: ic(correct ? "FaCheckCircle" : "FaTimesCircle", correct ? "g" : "r"), x: 5.15, y: y + 0.18, w: 0.5, h: 0.5, objectName: `${prefix}-icon` });
  T(s, correct ? "Correct: it fails. Only 3 of 5 tests pass." : "Not quite: it fails. Only 3 of 5 tests pass.",
    { x: 5.8, y: y + 0.14, w: 6.6, h: 0.38, fontSize: 15, bold: true, color: correct ? C.passL : C.failL, objectName: `${prefix}-t` });
  T(s, "The prompt said “capital small er tofat korbi na”: don't treat capital and small letters differently. The code compares them exactly, so is_palindrome(\"Racecar\") returns False. Asked in English, the same model got it right.",
    { x: 5.8, y: y + 0.52, w: 6.6, h: 0.66, fontSize: 9.5, color: C.dText, objectName: `${prefix}-b` });
}
{
  const s = pres.addSlide();
  frame(s, 2, { title: "Problem Statement", sub: "AI coding assistants are tested in clean English. Indians ask them in mixed languages." });
  card(s, 0.6, 2.15, 4.05, 2.45, { name: "p-stat" });
  T(s, "314.9M", { x: 0.88, y: 2.3, w: 3.6, h: 0.85, fontFace: H, fontSize: 46, bold: true, color: C.accD });
  T(s, "Indians are bilingual", { x: 0.88, y: 3.15, w: 3.6, h: 0.36, fontSize: 15, bold: true });
  T(s, "Census of India, 2011", { x: 0.88, y: 3.5, w: 3.6, h: 0.25, fontSize: 9.5, color: C.faint });
  T(s, "Many think and type in mixed languages, including when they ask AI to write code.", { x: 0.88, y: 3.82, w: 3.55, h: 0.7, fontSize: 11, color: C.muted });
  const probs = [["FaFlask", C.brand, "Tested in English", "HumanEval-XL covers 23 languages. None is Indian, none mixed."],
    ["FaEye", C.fail, "Nobody measures the gap", "Students get broken code from mixed prompts and never know why."]];
  probs.forEach(([icn, col, h, b], i) => {
    const y = 4.75 + i * 1.0;
    card(s, 0.6, y, 4.05, 0.88);
    badge(s, icn, 0.78, y + 0.18, 0.52, col);
    T(s, h, { x: 1.45, y: y + 0.1, w: 3.1, h: 0.3, fontSize: 12.5, bold: true });
    T(s, b, { x: 1.45, y: y + 0.4, w: 3.1, h: 0.45, fontSize: 9.5, color: C.muted });
  });
  // quiz widget (website style)
  card(s, 4.85, 2.15, 7.9, 4.55, { fill: C.dSurf, line: C.dLine, shColor: "000000", shOp: 0.3, name: "q-panel" });
  T(s, "SPOT THE FAILURE  ·  A REAL ANSWER FROM OUR TESTS", { x: 5.15, y: 2.32, w: 6, h: 0.24, fontSize: 9, bold: true, color: C.acc, charSpacing: 1.5 });
  T(s, "casual Benglish → GPT-OSS 120B", { x: 9.8, y: 2.32, w: 2.75, h: 0.24, fontSize: 9, color: C.dMuted, align: "right" });
  card(s, 5.15, 2.68, 3.65, 2.45, { fill: C.dSurf2, line: C.dLine, shadow: false, r: 0.12 });
  T(s, "THE PROMPT", { x: 5.33, y: 2.8, w: 3, h: 0.2, fontSize: 8, bold: true, color: C.dFaint, charSpacing: 1 });
  T(s, words(data.pal, 12.5), { x: 5.33, y: 3.05, w: 3.35, h: 2.0, lineSpacingMultiple: 1.08 });
  card(s, 8.95, 2.68, 3.6, 2.45, { fill: C.deep, line: C.dLine, shadow: false, r: 0.12 });
  [C.failL, C.acc, C.passL].forEach((col, i) => circle(s, 9.13 + i * 0.2, 2.84, 0.11, col));
  T(s, "the AI's reply", { x: 9.85, y: 2.8, w: 2.5, h: 0.2, fontFace: M, fontSize: 8.5, color: C.dFaint });
  T(s, codeRuns(PAL), { x: 9.13, y: 3.2, w: 3.35, h: 0.8, fontFace: M, fontSize: 11 });
  T(s, "5 hidden tests, e.g. is_palindrome(\"Racecar\") should be True", { x: 9.13, y: 4.5, w: 3.3, h: 0.5, fontSize: 9, color: C.dMuted });
  T(s, "Will this code pass all 5 tests?", { x: 5.15, y: 5.42, w: 3.6, h: 0.9, fontSize: 15, bold: true, color: C.dText, valign: "middle" });
  T(s, "Click to answer", { x: 5.15, y: 6.18, w: 3.6, h: 0.25, fontSize: 9, color: C.dFaint });
  const quizButtons = () => {
    pill(s, "✓  It passes", 8.95, 5.5, 1.72, 0.62, { fill: "0F3B33", line: C.passL, color: C.passL, size: 12.5, name: "trig-qp" });
    pill(s, "✕  It fails", 10.83, 5.5, 1.72, 0.62, { fill: "3B1424", line: C.failL, color: C.failL, size: 12.5, name: "trig-qf" });
  };
  quizButtons();
  if (!QA && !STATIC) { quizReveal(s, false, "qp"); quizReveal(s, true, "qf"); }
  notes(s, "AALIYA: 314.9 million Indians are bilingual, and we type to AI the way we talk. But AI coding tools are tested in clean English: HumanEval-XL has 23 languages and none is Indian. Here's a real answer from our tests. Judges, will it pass? (Click the button they pick.) It fails: the prompt said ignore capital letters and the code didn't. Nobody measures this gap. That's what MixCheck does.");
  if (QA) { [false, true].forEach((c) => { const q = pres.addSlide(); frame(q, 2, { title: "QA: quiz reveal " + (c ? "correct" : "wrong") }); card(q, 4.85, 2.15, 7.9, 4.55, { fill: C.dSurf, line: C.dLine }); quizReveal(q, c, c ? "qf" : "qp"); }); }
}

// =====================================================================
// 3. SOLUTION  (+ interactive Mix Dial)
// =====================================================================
const DIAL = [
  ["english", "English", "Clean English: all three models pass.", [["pass", "Passed 6 of 6"], ["pass", "Passed 6 of 6"], ["pass", "Passed 6 of 6"]]],
  ["hinglish_casual", "Hinglish", "Same task in Hinglish: GPT-OSS 120B's code now crashes on 1,000.", [["pass", "Passed 6 of 6"], ["fail", "Crashed on 1000"], ["pass", "Passed 6 of 6"]]],
  ["benglish_casual", "Benglish", "Benglish: GPT-OSS 20B named it bhai_indian_format, reading “bhai” (bro) as part of the name.", [["pass", "Passed 6 of 6"], ["fail", "Passed 4 of 6"], ["fail", "Renamed the function"]]],
  ["kanglish_casual", "Kanglish", "Kanglish: all three wrote working code, but both GPT-OSS models ignored “bari code kodu” (only code).", [["pass", "Passed 6 of 6"], ["warn", "Passed, ignored “only code”"], ["warn", "Passed, ignored “only code”"]]],
];
const MODELS = ["Gemini", "GPT-OSS 120B", "GPT-OSS 20B"];
const TABX = (k) => 4.85 + k * 1.95;
function dialState(s, k, prefix) {
  const [v, label, cap, st] = DIAL[k];
  const L = (n) => `${prefix}-${n}`;
  s.addShape(pres.shapes.RECTANGLE, { x: TABX(k) + 0.25, y: 3.47, w: 1.25, h: 0.06, fill: { color: C.acc }, line: { type: "none" }, objectName: L("ind") });
  s.addShape(pres.shapes.RECTANGLE, { x: 4.75, y: 3.6, w: 7.9, h: 2.98, fill: { color: C.dSurf }, line: { type: "none" }, objectName: L("cover") });
  card(s, 4.85, 3.62, 7.7, 1.4, { fill: C.deep, line: C.dLine, shadow: false, r: 0.1, name: L("pbox") });
  T(s, words(data.dial[v].tags, 11.5), { x: 5.03, y: 3.7, w: 7.35, h: 1.25, valign: "middle", objectName: L("prompt") });
  const pct = Math.round(data.dial[v].mix * 100);
  T(s, [{ text: pct + "%", options: { bold: true, fontSize: 14, color: C.dText } }, { text: "  of words not in English", options: { fontSize: 10, color: C.dMuted } }],
    { x: 4.85, y: 5.1, w: 3.2, h: 0.3, valign: "middle", objectName: L("mtxt") });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 8.2, y: 5.2, w: 4.35, h: 0.12, rectRadius: 0.06, fill: { color: C.dSurf2 }, line: { type: "none" }, objectName: L("mtrack") });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 8.2, y: 5.2, w: Math.max(0.12, 4.35 * data.dial[v].mix), h: 0.12, rectRadius: 0.06, fill: { color: C.acc }, line: { type: "none" }, objectName: L("mfill") });
  st.forEach(([kind, txt], i) => {
    const x = 4.85 + i * 2.6, col = kind === "pass" ? C.passL : kind === "fail" ? C.failL : C.acc;
    card(s, x, 5.48, 2.45, 0.62, { fill: C.deep, line: kind === "pass" ? C.dLine : col, shadow: false, r: 0.1, name: L("lc" + i) });
    circle(s, x + 0.15, 5.71, 0.16, col, { name: L("ld" + i) });
    T(s, MODELS[i], { x: x + 0.42, y: 5.53, w: 1.98, h: 0.24, fontSize: 10.5, bold: true, color: C.dText, objectName: L("lm" + i) });
    T(s, txt, { x: x + 0.42, y: 5.78, w: 2.0, h: 0.26, fontSize: 8.5, color: kind === "pass" ? C.dMuted : col, objectName: L("ls" + i) });
  });
  T(s, cap, { x: 4.85, y: 6.15, w: 7.7, h: 0.4, fontSize: 10.5, bold: true, color: k === 0 ? C.passL : C.acc, valign: "middle", objectName: L("cap") });
}
{
  const s = pres.addSlide();
  frame(s, 3, { title: "Solution", sub: "Same coding task in English and in mixed Indian languages. MixCheck runs the code and measures the gap." });
  const steps = [["FaLanguage", C.brand, "Paired prompts", "25 tasks, each in 10 versions. Only the language changes."],
    ["FaRobot", C.bnD, "Run on 3 AI models", "Gemini, GPT-OSS 120B and GPT-OSS 20B."],
    ["FaBalanceScale", C.accD, "Two scores", "Does the code pass every test? Did it reply with only the code, as asked?"]];
  steps.forEach(([icn, col, h, b], i) => {
    const y = 2.15 + i * 1.18;
    card(s, 0.6, y, 3.95, 1.05);
    badge(s, icn, 0.8, y + 0.24, 0.56, col);
    T(s, `${i + 1}. ${h}`, { x: 1.52, y: y + 0.13, w: 2.95, h: 0.3, fontSize: 13, bold: true });
    T(s, b, { x: 1.52, y: y + 0.45, w: 2.95, h: 0.55, fontSize: 9.5, color: C.muted });
  });
  pill(s, "Open the live dashboard  →", 0.6, 5.85, 3.95, 0.55, { fill: C.brand, line: null, color: "FFFFFF", size: 12, link: { url: URL, tooltip: URL }, name: "btn-try3" });
  T(s, "mixcheck-elrata.streamlit.app", { x: 0.6, y: 6.43, w: 3.95, h: 0.25, fontSize: 9, color: C.brand, align: "center" });
  // Mix Dial widget
  card(s, 4.65, 2.15, 8.1, 4.55, { fill: C.dSurf, line: C.dLine, shColor: "000000", shOp: 0.3, name: "d-panel" });
  T(s, "THE MIX DIAL  ·  CLICK A LANGUAGE", { x: 4.85, y: 2.3, w: 4.5, h: 0.24, fontSize: 9, bold: true, color: C.acc, charSpacing: 1.5 });
  T(s, [{ text: "Task: ", options: { color: C.dMuted } }, { text: "indian_format(1234567) → \"12,34,567\"", options: { fontFace: M, color: C.code } }],
    { x: 7.9, y: 2.3, w: 4.65, h: 0.24, fontSize: 9.5, align: "right" });
  dialState(s, 0, "d0");
  if (!QA && !STATIC) for (let k = 1; k < 4; k++) dialState(s, k, "d" + k);
  // tabs on top (they are the click triggers)
  DIAL.forEach(([, label], k) => pill(s, label, TABX(k), 2.68, 1.75, 0.72, { fill: C.dSurf2, line: C.dLine, color: C.dText, size: 12.5, name: "trig-d" + k }));
  notes(s, "TANMAY: Here's one real task from our 25: indian_format, so 1234567 becomes 12,34,567. Click English: all three models pass. Click Hinglish: GPT-OSS 120B now crashes on 1000. Click Benglish: GPT-OSS 20B named it bhai_indian_format. Click Kanglish: the code works, but both GPT-OSS models ignored 'bari code kodu', only code, and wrote long explanations. MixCheck does this for 25 tasks, 10 versions and 3 models, and it's live at mixcheck-elrata.streamlit.app.");
  if (QA) for (let k = 1; k < 4; k++) { const q = pres.addSlide(); frame(q, 3, { title: "QA: dial state " + k }); card(q, 4.65, 2.15, 8.1, 4.55, { fill: C.dSurf, line: C.dLine }); dialState(q, k, "d" + k);
    DIAL.forEach(([, label], j) => pill(q, label, TABX(j), 2.68, 1.75, 0.72, { fill: C.dSurf2, line: C.dLine, color: C.dText, size: 12.5 })); }
}

// =====================================================================
// 4. TECH STACK + WORKFLOW
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 4, { title: "Tech Stack + Workflow", sub: "From prompt to verdict, fully automatic, with untrusted AI code kept in a sandbox." });
  const flow = [["FaDatabase", C.bnD, "Prompts", "tasks.csv"], ["FaRobot", C.brand, "Ask 3 models", "run_all.py"], ["FaSearch", C.knD, "Find the code", "grade.py"],
    ["FaShieldAlt", C.pass, "Sandboxed run", "5 safety layers"], ["FaBalanceScale", C.accD, "Two scores", "results.csv"], ["FaChartBar", C.brand, "Dashboard", "app.py"]];
  const fx0 = 0.95, fstep = 2.2;
  s.addShape(pres.shapes.LINE, { x: fx0 + 0.35, y: 2.6, w: fstep * 5, h: 0, line: { color: C.brandL, width: 2, dashType: "dash" } });
  flow.forEach(([icn, col, h, b], i) => {
    const x = fx0 + i * fstep;
    badge(s, icn, x, 2.22, 0.76, col, "w", `auto${150 + i * 140}-f${i}`);
    T(s, h, { x: x - 0.6, y: 3.05, w: 1.96, h: 0.28, fontSize: 11.5, bold: true, align: "center", objectName: `auto${150 + i * 140}-fh${i}` });
    T(s, b, { x: x - 0.6, y: 3.32, w: 1.96, h: 0.24, fontFace: M, fontSize: 9, color: C.muted, align: "center", objectName: `auto${150 + i * 140}-fb${i}` });
  });
  const lanes = [
    ["Data", C.bnD, ["Python 3", "pandas", "250 prompts", "25 test files"]],
    ["Models", C.brand, ["Gemini API", "Groq API", "GPT-OSS 120B / 20B", "temperature 0"]],
    ["Grading", C.pass, ["separate process", "10 s time limit", "audit-hook sandbox", "no API keys inside"]],
    ["Dashboard", C.accD, ["Streamlit", "Plotly", "custom HTML/JS widgets", "Streamlit Cloud"]],
  ];
  lanes.forEach(([h, col, items], i) => {
    const x = 0.6 + i * 3.07;
    card(s, x, 3.85, 2.9, 2.2);
    T(s, h, { x: x + 0.22, y: 3.97, w: 2.5, h: 0.32, fontSize: 13.5, bold: true, color: col });
    items.forEach((t, k) => {
      const cx = x + 0.22 + (k % 2) * 1.25, cy = 4.38 + Math.floor(k / 2) * 0.78;
      T(s, t, { x: cx, y: cy, w: 1.2, h: 0.66, shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.1, fill: { color: C.soft }, line: { color: C.line, width: 0.75 },
        fontSize: 9, align: "center", valign: "middle", margin: 3 });
    });
  });
  card(s, 0.6, 6.17, 12.13, 0.55, { fill: C.ink, line: C.ink, shadow: false });
  T(s, [{ text: "48 automated checks", options: { bold: true, color: C.passL } }, { text: "  ·  a reference solution for every task  ·  ", options: { color: "DCD6F7" } },
    { text: "deployed live", options: { bold: true, color: C.acc } }, { text: "  ·  free API tiers, no GPU", options: { color: "DCD6F7" } }],
    { x: 0.8, y: 6.17, w: 11.7, h: 0.55, fontSize: 11.5, align: "center", valign: "middle" });
  notes(s, "TANMAY: The pipeline: prompts go to 3 models through their official APIs. Our grader finds the function the AI wrote and runs it against test cases in a separate process with a 10-second limit, no API keys, and a sandbox that blocks network, file writes and running programs. It gives two scores, and the Streamlit dashboard shows everything. 48 automated checks keep the grader honest, and it's deployed live.");
}

// =====================================================================
// 5. INNOVATION
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 5, { title: "Innovation", sub: "Existing benchmarks don't test code written from code-mixed Indian prompts. MixCheck does." });
  const pts = [["FaExchangeAlt", C.brand, "Paired prompts", "Same task, only the language changes, so any drop comes from the mixing."],
    ["FaVial", C.pass, "Graded by running code", "Test cases decide. No opinions, no hand-labelling."],
    ["FaBalanceScale", C.accD, "Two scores", "Does the code work? Did the AI follow the instructions?"],
    ["FaChartBar", C.knD, "Statistics built in", "95% ranges and Fisher's exact test separate real gaps from chance."],
  ];
  pts.forEach(([icn, col, h, b], i) => {
    const x = 0.6 + (i % 2) * 3.55, y = 2.15 + Math.floor(i / 2) * 2.3;
    card(s, x, y, 3.4, 2.15);
    badge(s, icn, x + 0.25, y + 0.25, 0.62, col);
    T(s, h, { x: x + 0.25, y: y + 1.0, w: 2.95, h: 0.34, fontSize: 14, bold: true });
    T(s, b, { x: x + 0.25, y: y + 1.36, w: 2.95, h: 0.7, fontSize: 10, color: C.muted });
  });
  card(s, 7.85, 2.15, 4.9, 4.45);
  const hdr = ["", "Indian\nlanguages", "Mixed\nprompts", "Tests\ncode", "Checks\ninstructions"];
  const cx = [8.0, 9.55, 10.33, 11.11, 11.89], cw = [1.55, 0.78, 0.78, 0.78, 0.8];
  hdr.forEach((h, j) => T(s, h, { x: cx[j], y: 2.3, w: cw[j], h: 0.55, fontSize: 8.5, bold: true, color: C.muted, align: j ? "center" : "left", valign: "bottom" }));
  const rows = [["HumanEval-XL", [0, 0, 1, 0]], ["LinCE", [1, 1, 0, 0]], ["GLUECoS", [1, 1, 0, 0]], ["MixCheck", [1, 1, 1, 1]]];
  rows.forEach(([name, v], r) => {
    const y = 3.0 + r * 0.78, me = name === "MixCheck";
    if (me) card(s, 7.95, y - 0.06, 4.7, 0.7, { fill: "FFF4E3", line: C.acc, lw: 1.5, shadow: false, r: 0.1, name: "auto900-me" });
    else s.addShape(pres.shapes.LINE, { x: 8.0, y: y + 0.68, w: 4.6, h: 0, line: { color: C.line, width: 0.75 } });
    T(s, name, { x: 8.1, y, w: 1.5, h: 0.58, fontSize: 12, bold: true, color: me ? C.accD : C.ink, valign: "middle", objectName: me ? "auto900-men" : undefined });
    v.forEach((ok, j) => s.addImage({ path: ic(ok ? "FaCheck" : "FaTimes", ok ? "g" : "f"), x: cx[j + 1] + cw[j + 1] / 2 - 0.13, y: y + 0.16, w: 0.26, h: 0.26,
      objectName: me ? `auto900-mc${j}` : undefined }));
  });
  T(s, "LinCE and GLUECoS include Hindi-English but test language understanding, not code. HumanEval-XL has 23 languages, none Indian.",
    { x: 8.05, y: 6.08, w: 4.55, h: 0.45, fontSize: 8, color: C.faint });
  notes(s, "AADITYA: What's new: paired prompts, so any drop comes from the language. Grading by running code. Two scores. And statistics built in, so we can tell real gaps from chance. Existing benchmarks either test code in single languages, or test mixed Hindi-English on understanding tasks. Nobody tests code from mixed prompts.");
}

// =====================================================================
// 6. IMPACT  (results, chart animates in)
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 6, { title: "Impact", sub: "What we measured across 750 graded answers: the code mostly works, the instructions break." });
  card(s, 0.6, 2.15, 7.6, 4.55);
  T(s, "Same casual style, only the language changes", { x: 0.85, y: 2.3, w: 5.5, h: 0.3, fontSize: 13, bold: true });
  T(s, "3 models × 25 tasks per language · one run each · temperature 0", { x: 0.85, y: 2.6, w: 6, h: 0.24, fontSize: 9, color: C.faint });
  [["Correct code", C.brandL], ["Replied with only code", C.acc]].forEach(([t, col], i) => {
    const x = 0.85 + i * 1.75;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 2.98, w: 0.15, h: 0.15, rectRadius: 0.03, fill: { color: col }, line: { type: "none" } });
    T(s, t, { x: x + 0.22, y: 2.93, w: 1.6, h: 0.25, fontSize: 9.5, color: C.muted });
  });
  const CAS = [["English", 1], ["Hinglish", 3], ["Benglish", 6], ["Tanglish", 8], ["Odia-English", 9], ["Kanglish", 7]];
  const ms = ["gemini", "groq", "groq-small"];
  const base = 6.05, maxH = 2.5, gw = 1.17, bw = 0.42, x0 = 0.95;
  s.addShape(pres.shapes.LINE, { x: 0.9, y: base, w: 7.1, h: 0, line: { color: C.line, width: 1 } });
  CAS.forEach(([lab, ci], i) => {
    const c = ms.reduce((a, m) => a + data.grid[m][ci], 0) / 75, f = ms.reduce((a, m) => a + data.fmt[m][ci], 0) / 75;
    [c, f].forEach((val, w) => {
      const h = Math.max(0.03, maxH * val), x = x0 + i * gw + 0.1 + w * (bw + 0.05), hot = lab === "Kanglish" && w === 1;
      const t0 = 200 + i * 110 + w * 50;
      s.addShape(pres.shapes.RECTANGLE, { x, y: base - h, w: bw, h, fill: { color: w ? C.acc : C.brandL }, line: { type: "none" }, objectName: `wipe${t0}-bar${i}${w}` });
      T(s, Math.round(val * 100) + "%", { x: x - 0.15, y: base - h - (hot ? 0.36 : 0.24), w: bw + 0.3, h: hot ? 0.32 : 0.22, fontSize: hot ? 15 : 8.5, bold: true,
        color: w ? C.accD : C.ink, align: "center", objectName: `auto${t0 + 500}-val${i}${w}` });
    });
    T(s, lab, { x: x0 + i * gw - 0.05, y: base + 0.08, w: gw + 0.1, h: 0.26, fontSize: 10, bold: lab === "Kanglish", color: lab === "Kanglish" ? C.knD : C.muted, align: "center" });
  });
  const pf = data.pf.kanglish_casual;
  const stats = [
    ["35% vs 100%", "Kanglish answers that replied with only the code, vs casual English. p < 0.001: not chance.", C.accD, C.acc],
    ["7 vs 0", "Renamed functions: 600 mixed prompts vs 150 English ones. One became bhai_indian_format.", C.fail, C.line],
    ["0% → 100%", "One English guard line made both GPT-OSS models reply with only code in Kanglish, with no loss in correct code.", C.pass, C.passL],
  ];
  stats.forEach(([b, t, col, ln], i) => {
    const y = 2.15 + i * 1.55, t0 = 1300 + i * 250;
    card(s, 8.4, y, 4.35, 1.42, { line: ln, lw: i === 0 ? 1.5 : 1, name: `auto${t0}-sc${i}` });
    T(s, b, { x: 8.65, y: y + 0.12, w: 3.9, h: 0.55, fontFace: H, fontSize: 25, bold: true, color: col, objectName: `auto${t0}-sb${i}` });
    T(s, t, { x: 8.65, y: y + 0.7, w: 3.95, h: 0.66, fontSize: 9.5, color: C.muted, objectName: `auto${t0}-st${i}` });
  });
  notes(s, "RITOBROTO: Across 750 graded answers, the purple bars, correct code, stay between 93 and 97 percent for every language. After a native speaker fixed our Kanglish wording, Kanglish code was as correct as English. But orange, following instructions, is 35 percent in Kanglish against 100 in casual English, and our significance test says that is not chance, p below 0.001. 7 answers renamed the function, all from mixed prompts. And we tested a fix: one fixed English line, reply with only one code block and name the function exactly, took both GPT-OSS models from 0 to 100 percent.");
}

// =====================================================================
// 7. TARGET AUDIENCE / MARKET
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 7, { title: "Target Audience / Market", sub: "Everyone building, teaching with or using AI coding tools in India." });
  const aud = [["FaLaptopCode", C.brand, "AI tool builders", "Find language blind spots before an Indian launch."],
    ["FaUserGraduate", C.accD, "Colleges and edtech", "Students ask in Hinglish. Know when answers can be trusted."],
    ["FaFlask", C.knD, "Researchers", "An open benchmark: a new language is one new column."],
    ["FaUsers", C.bnD, "Indian developers", "Asking in your own language shouldn't cost working code."]];
  aud.forEach(([icn, col, h, b], i) => {
    const x = 0.6 + (i % 2) * 3.75, y = 2.15 + Math.floor(i / 2) * 2.3;
    card(s, x, y, 3.6, 2.15);
    badge(s, icn, x + 0.25, y + 0.25, 0.62, col);
    T(s, h, { x: x + 0.25, y: y + 1.0, w: 3.15, h: 0.34, fontSize: 14, bold: true });
    T(s, b, { x: x + 0.25, y: y + 1.36, w: 3.15, h: 0.7, fontSize: 10, color: C.muted });
  });
  card(s, 8.15, 2.15, 4.6, 4.45, { line: C.acc, lw: 1.5 });
  T(s, "AI CODE TOOLS MARKET", { x: 8.4, y: 2.32, w: 4, h: 0.24, fontSize: 9, bold: true, color: C.accD, charSpacing: 1.5 });
  const bars = [["2023", 4.3, C.brandL], ["2028", 12.6, C.acc]];
  bars.forEach(([yr, v, col], i) => {
    const h = 2.2 * v / 12.6, x = 8.75 + i * 1.6, by = 5.1;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: by - h, w: 1.05, h, rectRadius: 0.08, fill: { color: col }, line: { type: "none" }, objectName: `wipe${300 + i * 300}-mk${i}` });
    T(s, `USD ${v}B`, { x: x - 0.3, y: by - h - 0.36, w: 1.65, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: i ? C.accD : C.brand, align: "center", objectName: `auto${700 + i * 300}-mv${i}` });
    T(s, yr, { x, y: by + 0.06, w: 1.05, h: 0.26, fontSize: 10, color: C.muted, align: "center" });
  });
  T(s, "about 24% growth a year", { x: 11.45, y: 3.2, w: 1.15, h: 0.6, fontSize: 9, bold: true, color: C.accD });
  T(s, "Source: MarketsandMarkets", { x: 8.4, y: 5.38, w: 4.1, h: 0.2, fontSize: 8, color: C.faint, align: "center" });
  s.addShape(pres.shapes.LINE, { x: 8.4, y: 5.65, w: 4.1, h: 0, line: { color: C.line, width: 1 } });
  T(s, [{ text: "314.9M ", options: { bold: true, color: C.accD, fontFace: H, fontSize: 16 } }, { text: "bilingual Indians who could be typing those prompts (Census 2011).", options: { color: C.muted } }],
    { x: 8.4, y: 5.7, w: 4.15, h: 0.8, fontSize: 10 });
  notes(s, "AALIYA: Who needs this: AI tool builders before launching in India, colleges and edtech whose students ask in Hinglish, researchers, and every Indian developer. The market for AI coding tools is expected to grow from 4.3 to 12.6 billion dollars by 2028.");
}

// =====================================================================
// 8. REVENUE MODEL
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 8, { title: "Revenue Model", sub: "A free open core builds trust. Teams pay to test their own models." });
  const tiers = [["FaGithub", "Open-source core", "Free", ["Benchmark + dashboard on GitHub", "Community adds languages", "Builds trust and adoption"], false, C.brand, "For students and researchers"],
    ["FaServer", "MixCheck Pro", "₹799 / month", ["Test your own model via an API", "Private reports for your team", "Alerts when an update gets worse"], true, C.accD, "For startups and product teams"],
    ["FaShieldAlt", "Custom audits", "One-time fee", ["Pre-launch testing of your product", "Your languages and domains", "A “MixCheck Verified” report"], false, C.knD, "For companies launching in India"]];
  tiers.forEach(([icn, h, price, items, hot, col, who], i) => {
    const x = 0.6 + i * 4.1, y = hot ? 2.05 : 2.2;
    card(s, x, y, 3.9, hot ? 4.6 : 4.3, { line: hot ? C.acc : C.line, lw: hot ? 2 : 1, name: `auto${150 + i * 200}-t${i}` });
    if (hot) pill(s, "MOST TEAMS", x + 2.5, y + 0.22, 1.2, 0.3, { fill: C.acc, line: null, color: "FFFFFF", size: 8.5, name: `auto${350}-tag` });
    badge(s, icn, x + 0.28, y + 0.25, 0.62, col, "w", `auto${150 + i * 200}-ti${i}`);
    T(s, h, { x: x + 0.28, y: y + 1.02, w: 3.4, h: 0.36, fontSize: 15, bold: true, objectName: `auto${150 + i * 200}-th${i}` });
    T(s, price, { x: x + 0.28, y: y + 1.4, w: 3.4, h: 0.5, fontFace: H, fontSize: 22, bold: true, color: col, objectName: `auto${150 + i * 200}-tp${i}` });
    s.addShape(pres.shapes.LINE, { x: x + 0.28, y: y + 2.0, w: 3.34, h: 0, line: { color: C.line, width: 1 }, objectName: `auto${150 + i * 200}-tl${i}` });
    items.forEach((t, k) => {
      s.addImage({ path: ic("FaCheck", "g"), x: x + 0.28, y: y + 2.25 + k * 0.58, w: 0.2, h: 0.2, objectName: `auto${150 + i * 200}-tc${i}${k}` });
      T(s, t, { x: x + 0.6, y: y + 2.18 + k * 0.58, w: 3.1, h: 0.5, fontSize: 10.5, color: C.muted, objectName: `auto${150 + i * 200}-tx${i}${k}` });
    });
    pill(s, who, x + 0.28, y + (hot ? 4.0 : 3.7), 3.34, 0.38, { fill: hot ? "FFF4E3" : C.soft, line: hot ? C.acc : C.line, color: col, size: 9.5, name: `auto${150 + i * 200}-tw${i}` });
  });
  notes(s, "AALIYA: The benchmark stays free and open, which builds trust. Teams pay 799 rupees a month for MixCheck Pro to test their own model through an API, with private reports and alerts. Companies can buy a one-time audit before launch.");
}

// =====================================================================
// 9. FUTURE IMPROVEMENTS
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 9, { title: "Future Improvements", sub: "From a benchmark to a safety net for every AI coding tool used in India." });
  s.addShape(pres.shapes.LINE, { x: 1.9, y: 2.62, w: 9.5, h: 0, line: { color: C.brandL, width: 2, dashType: "dash" } });
  const steps = [["FaUserCheck", "NOW", "Done today", "A native Kannada speaker reviewed our Kanglish prompts and we re-ran them. A one-line English guard fixed “only code”: 0% → 100%."],
    ["FaLanguage", "NEXT", "Wider and stronger", "Native review of every prompt. Marathi, Telugu, Malayalam. Several runs per prompt."],
    ["FaWrench", "THEN", "Fix it, not just find it", "A plug-in that adds the guard line automatically. Translating first didn’t work: it turned “bari code kodu” into “Provide the code”."],
    ["FaTrophy", "VISION", "Public leaderboard", "Re-run MixCheck on every model update and publish the results for everyone."]];
  steps.forEach(([icn, lab, h, b], i) => {
    const x = 0.6 + i * 3.07, now = i === 0, t0 = 150 + i * 260;
    badge(s, icn, x + 1.0, 2.18, 0.88, now ? C.acc : C.brand, "w", `auto${t0}-rb${i}`);
    card(s, x, 3.35, 2.9, 2.5, { line: now ? C.acc : C.line, lw: now ? 1.75 : 1, name: `auto${t0}-rc${i}` });
    T(s, lab, { x: x + 0.25, y: 3.52, w: 2.4, h: 0.26, fontSize: 10, bold: true, color: now ? C.accD : C.brand, charSpacing: 2, objectName: `auto${t0}-rl${i}` });
    T(s, h, { x: x + 0.25, y: 3.85, w: 2.45, h: 0.62, fontSize: 14, bold: true, objectName: `auto${t0}-rh${i}` });
    T(s, b, { x: x + 0.25, y: 4.5, w: 2.45, h: 1.3, fontSize: 10.5, color: C.muted, objectName: `auto${t0}-rt${i}` });
  });
  card(s, 0.6, 6.05, 12.13, 0.6, { fill: C.ink, line: C.ink, shadow: false, name: "auto1300-goal" });
  T(s, [{ text: "Goal: ", options: { bold: true, color: C.acc } }, { text: "AI coding tools that work as well in Kanglish as they do in English.", options: { bold: true, color: "FFFFFF" } }],
    { x: 0.8, y: 6.05, w: 11.7, h: 0.6, fontSize: 13.5, align: "center", valign: "middle", objectName: "auto1300-goalt" });
  notes(s, "AADITYA: Today a native Kannada speaker reviewed our Kanglish prompts and we re-ran them, and we tested two fixes. A one-line English guard fixed only-code completely. Translating to English first did not: the AI translated bari code kodu as provide the code and lost the word only. Next: native review of every prompt, more languages, several runs per prompt. Then a plug-in that adds the guard automatically. The vision is a public leaderboard that re-runs on every model update.");
}

// =====================================================================
// 10. THANK YOU
// =====================================================================
{
  const s = pres.addSlide();
  frame(s, 10, { titleBg: true });
  s.addImage({ path: A + "wordmark.png", x: 0.55, y: 1.15, w: 3.6, h: 3.6 * 420 / 1447, objectName: "!!wordmark" });
  T(s, "Thank You", { x: 0.6, y: 2.25, w: 7.2, h: 1.0, fontFace: H, fontSize: 54, bold: true, objectName: "!!title" });
  T(s, "Questions?", { x: 0.6, y: 3.25, w: 7.2, h: 0.65, fontFace: H, fontSize: 30, bold: true, color: C.brand });
  // QR card
  card(s, 9.15, 1.2, 3.6, 3.15, { line: C.brand, lw: 1.5, name: "qr-card" });
  s.addImage({ path: A + "qr.png", x: 9.95, y: 1.38, w: 2.0, h: 2.0, hyperlink: { url: URL, tooltip: URL }, objectName: "qr" });
  T(s, "Scan or click to try MixCheck live", { x: 9.3, y: 3.42, w: 3.3, h: 0.3, fontSize: 10.5, bold: true, align: "center" });
  s.addText([{ text: "mixcheck-elrata.streamlit.app", options: { hyperlink: { url: URL, tooltip: URL } } }], { x: 9.3, y: 3.75, w: 3.3, h: 0.3, fontFace: B, fontSize: 10, bold: true, color: C.brand, align: "center", margin: 0, objectName: "btn-url10" });
  const team = [["Tanmay", "Team lead & developer", "Builds the app, runs the live demo", C.brand], ["Ritobroto", "Testing & evaluation", "Runs the models, checks the results", C.bnD],
    ["Aaditya", "Dataset & design", "Coding tasks, prompts, design", C.accD], ["Aaliya", "Research & presentation", "Problem research, the pitch", C.knD]];
  team.forEach(([n, r, b, col], i) => {
    const x = 0.6 + i * 3.07, t0 = 200 + i * 150;
    card(s, x, 4.6, 2.9, 1.6, { name: `auto${t0}-mc${i}` });
    circle(s, x + 0.25, 4.82, 0.62, col, { name: `auto${t0}-md${i}` });
    T(s, n[0], { x: x + 0.25, y: 4.82, w: 0.62, h: 0.62, fontFace: H, fontSize: 20, bold: true, color: "FFFFFF", align: "center", valign: "middle", objectName: `auto${t0}-mi${i}` });
    T(s, n, { x: x + 1.0, y: 4.84, w: 1.85, h: 0.32, fontSize: 15, bold: true, objectName: `auto${t0}-mn${i}` });
    T(s, r, { x: x + 1.0, y: 5.16, w: 1.85, h: 0.28, fontSize: 8.5, bold: true, color: col, objectName: `auto${t0}-mr${i}` });
    T(s, b, { x: x + 0.25, y: 5.6, w: 2.45, h: 0.5, fontSize: 10, color: C.muted, objectName: `auto${t0}-mb${i}` });
  });
  notes(s, "AALIYA: Thank you! Scan the code to try MixCheck yourself. We'd love your questions.");
}

pres.writeFile({ fileName: __dirname + (QA ? "/qa_raw.pptx" : STATIC ? "/static_raw.pptx" : "/raw.pptx") }).then(() => console.log("written"));
